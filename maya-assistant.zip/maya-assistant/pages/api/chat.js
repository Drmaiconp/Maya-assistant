export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).json({ error: "Method not allowed" });

  const { messages } = req.body;

  const MCP_SERVERS = [
    { type: "url", url: "https://calendarmcp.googleapis.com/mcp/v1", name: "google-calendar" },
    { type: "url", url: "https://gmailmcp.googleapis.com/mcp/v1", name: "gmail" },
    { type: "url", url: "https://ai.todoist.net/mcp", name: "todoist" },
    { type: "url", url: "https://context.era.app", name: "era-context" },
    { type: "url", url: "https://mcp.stripe.com", name: "stripe" },
  ];

  const SYSTEM_PROMPT = `Você é a assistente pessoal exclusiva de Maicon, médico e empresário fundador da Clickuscare.

IDENTIDADE: Você se chama "Maya" — assistente pessoal do Maicon.

REGRAS IMPORTANTES:
- Reuniões NUNCA podem ser agendadas antes das 10h sem autorização explícita de Maicon
- Sempre responda em português brasileiro
- Seja direta, eficiente e proativa
- Use os apps conectados para buscar informações em tempo real quando necessário

CONTEXTO DO MAICON:
- Médico especialista em longevidade e protocolos NAD+/peptídeos
- Fundador da Clickuscare (plataforma de saúde white label)
- Tem cartões: Amex Business Platinum, Amazon Business Prime, Capital One (BJ's, Quicksilver, Savor x3), Credit One (Wander, Platinum)
- Usa Stripe para faturamento da Clickuscare (~$49k MRR)
- Projetos no Todoist: Reuniões, Finanças Mensais, Cronograma de Custos

APPS CONECTADOS: Google Calendar, Gmail, Todoist, Era Context (cartões), Stripe (Clickuscare)`;

  try {
    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": process.env.ANTHROPIC_API_KEY,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: "claude-sonnet-4-20250514",
        max_tokens: 1000,
        system: SYSTEM_PROMPT,
        messages,
        mcp_servers: MCP_SERVERS,
      }),
    });

    const data = await response.json();
    const text = data.content
      ?.filter((b) => b.type === "text")
      .map((b) => b.text)
      .join("\n") || "Desculpe, não consegui processar sua solicitação.";

    res.status(200).json({ text });
  } catch (err) {
    res.status(500).json({ error: "Erro ao conectar com a API" });
  }
}
