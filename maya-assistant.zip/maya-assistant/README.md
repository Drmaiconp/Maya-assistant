# Maya — Assistente Pessoal do Maicon

## Deploy na Vercel (passo a passo)

### 1. Subir o código no GitHub
1. Acesse github.com e crie um novo repositório chamado `maya-assistant`
2. Faça upload de todos os arquivos desta pasta

### 2. Deploy na Vercel
1. Acesse vercel.com e clique em "New Project"
2. Importe o repositório `maya-assistant` do GitHub
3. Clique em "Deploy"

### 3. Configurar a chave de API
1. No painel da Vercel, vá em Settings → Environment Variables
2. Adicione:
   - Name: `ANTHROPIC_API_KEY`
   - Value: `sua-chave-sk-ant-...`
3. Clique em Save e faça Redeploy

### 4. Acessar
Seu app estará disponível em: `https://maya-assistant.vercel.app`

## Tecnologias
- Next.js 14
- React 18
- Anthropic Claude API
- MCP Servers (Google Calendar, Gmail, Todoist, Era Context, Stripe)
